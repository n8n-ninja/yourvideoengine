import { APIGatewayProxyEvent, APIGatewayProxyResult } from "aws-lambda";
export declare const helloWorld: (event: APIGatewayProxyEvent) => Promise<APIGatewayProxyResult>;
